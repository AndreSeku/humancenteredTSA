#!/usr/bin/env python3

'''
Methods for cleaning of timeseries data.
'''
# TODO 
# NaN's: [1,2,3,4,1,2,3,NaN,1,2,3]
# Lücken: [1,2,3,43,1,2,3]
# Fehlerhafte daten: [1,2,3,5,'asd','asd', '1',2,3,4]

